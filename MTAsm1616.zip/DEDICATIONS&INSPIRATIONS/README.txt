Dedicated to my Daddy Guillermo and my Mommy Helen..
To Sofia, Tatiana, Zoe, Casper, Chanteuse, Christine, Emma N., Renee, Nikol, Emma F., Evelyn D., Oxana, Anna A., MARUV, Saiki, Warocha, Karina, Sirena, Cixi, Miss Neptune, Miss Brighton and the 22nd, see you coz i love you. 
To Syra, Shira, Bailey, Dixie, Jenna - HAsAsIN solid team
Belmar, Brian, Ernie, Kristoffer, Francis, Leslie, Hanzel, Ed. Richie - Sigma Tau 1999Ba UP Diliman
Travis, Santiago, Giacomo - Trinicaria/Triangulum team
Raymund, Archie, Paul Christian, Ricky - Zelotes solid team
Lawrence Muller - greatest 80's hacker ever.
Sam and Crew - hype. saracen yemeni
Ariana Miyamoto, Pia Wurtzbach, Catriona Gray, Flora Coquerel, Luigi Gomez and the rest - ALWAYS HOT
the Tiktok Sorority - Epic stuff. keep it up
rRlf, BCVG, 29a, brigada ocho and all the guys who made the vx scene exciting - special mention to gigabyte aka kim vanvaeck.
to the guys and gals that i met in up diliman, isabela state university, laguardia community college - hey!!!
to the (war)bands that i listen to in spotify, youtube etc.
to the persons who listened to my busking in the MTA subways
to mayor eric adams, president barack obama and president joe biden.
to president dubya, president bongbong marcos, vice president sarah duterte
to president duterte and president marcos, president jose p. laurel, president manuel quezon
to the Church. to my neighbors in spirit and at heart and literal neighbors.
to my loving relatives in the Philippines..
and to everyone.
and to New York City and New York, Cubao...

Lord-God..

Thank you..

Let's go..

I love you all.

~ alCoPaUL [GIMO][As][aBrA][NPA][b8][BCVG][rRlf] 2/1/2023 NYC
  w32.perrun

https://www.mastodon.social/@alcopaul
https://linkt.ree/alcopaul